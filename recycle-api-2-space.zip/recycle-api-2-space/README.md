---
title: Recycle Api
emoji: 📉
colorFrom: red
colorTo: purple
sdk: docker
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
